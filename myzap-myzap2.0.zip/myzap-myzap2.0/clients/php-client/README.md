Cliente PHP - Breve
