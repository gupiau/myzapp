#!/bin/bash
docker-compose exec myzap_2dev ../../../bin/bash